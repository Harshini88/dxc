package com.dxc.pms.model;
 
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.dxc.pms.dbcom.MyConnection;
 
public class Client {
 
    public static void main(String[] args)throws ClassNotFoundException, SQLException { 
        Scanner scanner = new Scanner(System.in);
        Connection con = MyConnection.getDBConnection();
 
        while (true) {
 
            System.out.println("MAIN MENU");
            System.out.println("1. Add customer");
            System.out.println("2. Delete customer");
            System.out.println("3. Update customer");
            System.out.println("4. Find customer by Id");
            System.out.println("5. Find All customer ");
            System.out.println("6. E X I T");
            System.out.print("Please enter your choice (1-6)");
            int choice = scanner.nextInt();
            switch (choice) {
            case 1:
                System.out.println("Adding customer : ");
                break;
            case 2:
                System.out.println("Deleting customer : ");
                break;
            case 3:
                System.out.println("Updating customer : ");
                break;
            case 4:
                System.out.println("Finding customer by id : ");
                break;
            case 5:
                System.out.println("Displaying all the  customer : ");
                Statement statement = con.createStatement();
                ResultSet res = statement.executeQuery("select * from hr.customer");
                while(res.next()){
                System.out.println(res.getString(1)+" ");
                System.out.println(res.getString(2)+" ");
                System.out.println(res.getString(3)+" ");
                System.out.println(res.getString(4));
                }
               
                break;
            case 6:
                System.out.println("Thanks for using my program");
                System.exit(0);
            default:
                System.out.println("Incorrect Option . Please select (1-6)");
            }
        }
    }
}
